Products in order list (admin)

This extension adds a short summary of ordered products the admin order list and in the dashboard.
A new column shows information in the format:
"quantity x model"

The extension requires VQMOD. No files are overwritten.

Tested for opencart 1.5.4.1.
Please add in the comments if it's working for other releases. I'll add this information.

If you like the extension, rate it. This the best way to say thanks, since the extension is free.

Installation
=====================================================
Requires VQMOD.
Copy the vqmod directory to your store. That's all!

Setup
=====================================================
None.

Usage
=========
In the admin part.
1. Go to Sales -> Orders
Check the new column
2. Go to Dashboard
Check the new column

Need Help?
=========
Please get in touch with me in comment

ChangeLog
=======
Current version: 1.0.0

1.0.0
-init release

