$.fn.nwaOption = function(b, c, d, e) {

    $('#nwa_product').hide();

    var selected = new Array();
    var selected_names = new Array();

    $('.options').find('input:checked').each(function() {

        selected.push($(this).val());

        var name = $(this).next();

        if (typeof (name) != 'undefined') {
            selected_names.push(name.text().trim());
        } else {
            selected_names.push('unknow');
        }

    });

    $('.options').find('select').each(function() {

        if ($(this).val()) {
            selected.push($(this).val());
            selected_names.push($(this).find('option:selected').text().trim());
        }

    });


    var selected_string = selected.join(':');
    var selected_name_string = selected_names.join(', ');// + ' ' + nwa_open_stock_options[selected_string];

    // alert(selected_string);

    if (typeof (nwa_open_stock_options[selected_string]) != 'undefined') {

        $('#nwa_option_id').val();
        $('#nwa_option_value_id').val(nwa_open_stock_options[selected_string]);
 
        $('#nwa_product_box_title').text(nwa_open_stock_title.replace('{options_names}',selected_name_string));

        $('#nwa_product_container').html($('#nwa_product'));

        $('#nwa_product_close').remove();

        $('#nwa_product').prependTo($(this).parent().parent()).show('slow');

        $('#nwa_email').focus();

    }
};