<?php
// keep the {options_names} to be replaced to real options names
$_['heading_title_open_stock'] = 'The combination [{options_names}] is Out of Stock ';

?>