<?php

$_['heading_title_open_stock'] = 'A combina&ccedil;&atilde;o {options_names} est&aacute; indispon&iacute;vel';

?>